// discors.js
const { Client, GatewayIntentBits, Partials, Collection } = require("discord.js");
const { AutoPoster } = require('topgg-autoposter')
require('dotenv').config();
const db_connect = require("./src/database/connect.js")
const dailyRestart = require("./src/util/daily_reset.js")

// client
const client = new Client({
    intents: [Object.keys(GatewayIntentBits)],
    partials: [Object.keys(Partials)]
});

// permite importar o client externamente
module.exports = client;

// acesso - arquivos
const fs = require("fs");

// collections
client.commands = new Collection();

// handlers
const handlers = fs.readdirSync("./src/handler").filter((file) => file.endsWith('.js'));
for (const file of handlers) {
    require(`./src/handler/${file}`)(client);
};
client.handleCommands("./src/Commands");
// apagando o console
console.clear();

//Functions/Classes
db_connect();
dailyRestart();
AutoPoster(process.env.topgg, client)
//Logando no bot
client.login(process.env.token);

// unhandledRejection

process.on('unhandledRejection', (reason, promise) => {
  console.log(`🚫 Erro Detectado:\n\n${reason.stack}`);
});

process.on('uncaughtException', (error, origin) => {
  console.log(`🚫 Erro Detectado:]\n\n${error.stack}`);
});

process.on('uncaughtExceptionMonitor', (error, origin) => {
  console.log(`🚫 Erro Detectado:\n\n${error.stack}`);
});
